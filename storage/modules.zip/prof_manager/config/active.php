<?php

declare(strict_types=1);

/**
 * Profit Manager Module — Active Config Overrides
 * Written by the admin UI. Do not edit manually.
 */

return array (
  'enabled' => true,
  'mode' => 'demo',
  'active_profile' => 'auto',
  'profiles' => 
  array (
    'long' => 
    array (
      'profile_name' => 'legacy_safe_long',
      'init_roi' => 2.0,
      'activation_roi' => 10.0,
      'step_roi' => 3.0,
      'lock_buffer_roi' => 2.0,
      'lock_floor_roi' => 5.0,
      'min_update_interval_sec' => 30,
      'min_price_distance_pct' => 0.14999999999999999,
      'min_roi_step' => 1.0,
      'max_updates_per_run' => 20,
      'default_tick_size' => 0.0001,
      'hybrid_enabled' => true,
      'pattern_confirmation_window_sec' => 300,
      'pattern_confirmation_min_ticks' => 2,
      'guard_roi_distance' => 3.0,
      'breathing_roi_distance_min' => 5.0,
      'breathing_roi_distance_max' => 10.0,
      'hybrid_min_close_roi' => 5.0,
      'detection_min_price_points' => 15,
      'detection_max_price_points' => 60,
      'detection_lookback_sec' => 3600,
      'detection_weak_high_margin_pct' => 0.10000000000000001,
      'detection_min_score' => 3,
      'confirm_support_break_pct' => 0.14999999999999999,
      'confirm_new_high_margin_pct' => 0.20000000000000001,
      'confirm_strong_drop_pct' => 2.0,
      'parser2_storage_path' => '',
      'price_history_enabled' => true,
      'price_history_max_points' => 120,
      'price_history_min_points_for_detector' => 10,
      'hybrid_simulation_enabled' => false,
      'hybrid_simulation_pattern_symbol' => '',
      'hybrid_simulation_force_detect' => false,
      'hybrid_simulation_force_confirm' => false,
      'hybrid_simulation_force_reject' => false,
    ),
  ),
);
