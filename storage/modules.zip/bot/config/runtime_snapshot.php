<?php

declare(strict_types=1);

/**
 * Bot Module — Runtime Snapshot
 * Auto-written after each tick. Do not edit manually.
 * snapshot_at: 2026-04-29T20:12:05+01:00
 */

return array (
  'snapshot_at' => '2026-04-29T20:12:05+01:00',
  'bot_id' => 'bot',
  'mode' => 'demo',
  'enabled' => true,
  'tick_at' => '2026-04-29T20:12:05+01:00',
  'last_tick_result' => 'ok',
  'strategies_discovered_total' => 4,
  'strategies_enabled_total' => 3,
  'strategies_disabled_total' => 1,
  'handoff_sources_active_total' => 3,
  'handoff_signals_processed' => 20,
  'allowed_entry_modes' => 
  array (
    0 => 'limit',
    1 => 'market',
  ),
  'max_bot_budget' => 10.0,
  'max_bot_leverage' => 50,
  'order_queue_total' => 0,
  'active_orders_count' => 0,
  'active_positions_count' => 5,
  'config_valid' => true,
  'effective_config' => 
  array (
    'mode' => 'demo',
    'enabled' => true,
  ),
);
