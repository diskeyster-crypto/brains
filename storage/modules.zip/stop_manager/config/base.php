<?php

declare(strict_types=1);

/**
 * Stop Manager Module — Base Config
 *
 * Stop Manager is the sole owner of stop-loss computation.
 * Strategy modules provide signal profile references only.
 * Bot module provides position state only.
 * This module owns the stop math.
 *
 * Override individual values in active.php without touching this file.
 *
 * Stop modes:
 *   liq_distance_percent — stop placed between liquidation price and entry price.
 *
 *   liq_distance_percent is the % of the way from liquidation toward entry where
 *   the stop is placed.  Value is clamped 1..99.
 *
 *   For long:  stop = liq_price + (liq_distance_percent / 100) * (entry_price - liq_price)
 *   For short: stop = liq_price - (liq_distance_percent / 100) * (liq_price - entry_price)
 *
 *   Examples:
 *     liq_distance_percent = 90  → stop is 90% of the way from liq to entry (close to entry)
 *     liq_distance_percent = 10  → stop is 10% of the way from liq to entry (close to liq)
 *
 * Execution modes:
 *   demo  — stop computation for Bybit Demo positions + call setTradingStop on Bybit Demo
 *           (set demo_execute_stops=false to suppress the exchange call)
 *   live  — stop computation for live positions + call setTradingStop on live account
 */

return [
    // Core identity
    'module_id' => 'stop_manager',
    'enabled'   => false,
    'mode'      => 'demo',  // demo | live
                            // demo = stop computation for Bybit Demo positions
                            //        + setTradingStop on Bybit Demo (if demo_execute_stops=true)
                            // live = stop computation for live positions

    // Stop computation
    'stop_mode'            => 'liq_distance_percent',
    'liq_distance_percent' => 90,  // % of way from liq to entry where stop is placed (1..99)

    // Breakeven / profit-lock rule
    'breakeven_enabled'          => false,
    'breakeven_trigger_roi'      => 10.0,  // ROI% that triggers the shift
    'breakeven_profit_lock_roi'  => 3.0,   // ROI% locked after shift

    // Bot positions source path (relative to repo root)
    'bot_positions_path' => 'modules/bot/storage/active_positions.json',

    // Demo execution: when mode=demo, actually call Bybit Demo setTradingStop API.
    // Credentials are read from the bot module config (demo_api_key / demo_api_secret).
    // Set to false to keep demo mode as local-only computation.
    'demo_execute_stops' => true,

    // Path to the bot module directory (relative to repo root).
    // Used to locate the bot config when reading demo API credentials.
    'bot_module_dir' => 'modules/bot',

    // Cron / batch
    'tick_interval_sec'   => 60,
    'max_runtime_seconds' => 25,
];
