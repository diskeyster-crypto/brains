<?php

declare(strict_types=1);

/**
 * Double Bottom Long — Runtime Snapshot
 * Auto-written after each completed scan cycle.
 * snapshot_at: 2026-04-29T20:10:59+01:00
 */

return array (
  'snapshot_at' => '2026-04-29T20:10:59+01:00',
  'strategy_id' => 'double_bottom_long',
  'side' => 'long',
  'mode' => 'demo',
  'enabled' => true,
  'timeframe' => 'H4',
  'cycle_id' => 229,
  'universe_mode' => 'all',
  'batch_size' => 200,
  'max_symbols_per_run' => 200,
  'continuous_scan_enabled' => true,
  'stop_mode' => 'fixed_from_liq_zone',
  'stop_from_liq_buffer_value' => 0.002,
  'stop_from_liq_buffer_type' => 'percent',
  'bot_budget' => 0.0,
  'bot_leverage' => 1,
  'entry_mode' => 'limit',
  'reverse_pattern_close_enabled' => false,
  'tp_enabled' => false,
  'tp_mode' => 'fixed_r',
  'tp_value' => 2.0,
  'config_valid' => true,
  'effective_config' => 
  array (
    'mode' => 'demo',
    'enabled' => true,
  ),
);
