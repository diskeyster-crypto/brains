<?php

declare(strict_types=1);

/**
 * Stop Manager Module — Runtime Snapshot
 * Auto-written after each tick. Do not edit manually.
 * snapshot_at: 2026-04-29T20:12:05+01:00
 */

return array (
  'snapshot_at' => '2026-04-29T20:12:05+01:00',
  'module_id' => 'stop_manager',
  'mode' => 'demo',
  'enabled' => true,
  'tick_at' => '2026-04-29T20:12:05+01:00',
  'last_tick_result' => 'ok',
  'positions_seen_total' => 3,
  'stops_active_total' => 3,
  'config_valid' => true,
  'effective_config' => 
  array (
    'mode' => 'demo',
    'enabled' => true,
  ),
);
