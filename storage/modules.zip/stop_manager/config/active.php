<?php

declare(strict_types=1);

/**
 * Stop Manager Module — Active Config Overrides
 * Written by the admin UI. Edit via the config page.
 */

return array (
  'enabled' => true,
  'mode' => 'demo',
  'stop_mode' => 'liq_distance_percent',
  'liq_distance_percent' => 70,
  'breakeven_enabled' => false,
  'breakeven_trigger_roi' => 10.0,
  'breakeven_profit_lock_roi' => 3.0,
);
