<?php

declare(strict_types=1);

/**
 * Strategy Active Config Overrides — controlled_daily_momentum_long
 * Written by the admin UI. Do not edit manually.
 */

return array (
  'enabled' => true,
  'mode' => 'demo',
  'handoff_enabled' => true,
  'max_symbols_per_run' => 200,
  'batch_size' => 200,
);
