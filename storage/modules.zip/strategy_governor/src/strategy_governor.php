<?php

declare(strict_types=1);

/**
 * Strategy Governor — Core Engine (V2 Shadow Signal Lifecycle)
 *
 * Observes strategy signals, bot queues, active positions and closed trades.
 * Writes shadow-only recommended decisions.  Does NOT touch bot queues,
 * strategy files, Profit Manager, Stop Manager or any exchange API.
 *
 * Signal lifecycle:
 *   - Signals are normalised into a canonical structure keyed by governor_signal_key.
 *   - Signals without a signal_id are immediately rejected (invalid).
 *   - Signals older than max_signal_age_seconds are rejected (stale) without
 *     re-journalling on subsequent runs.
 *   - Corridor-like strategies that require confirmation: pending → wait_confirmation
 *     for N ticks, then final decision.
 *   - Default strategies: immediate shadow decision (approve_demo_shadow or
 *     reject_shadow) without any forced wait.
 *   - Final decisions are kept in pending_signals.json for TTL visibility.
 *   - Decision journal is written only when state actually changes (no spam).
 *
 * Entry point called by StrategyGovernorService:
 *   run(): array   — executes one Governor tick, returns last_run summary
 */

namespace Modules\StrategyGovernor;

final class StrategyGovernor
{
    // ── Decision state constants ──────────────────────────────────────────────
    private const STATE_OBSERVED            = 'observed';
    private const STATE_WAIT_CONFIRM        = 'wait_confirmation';
    private const STATE_APPROVE_DEMO_SHADOW = 'approve_demo_shadow';
    private const STATE_APPROVE_LIVE_SHADOW = 'approve_live_shadow';
    private const STATE_REJECT_SHADOW       = 'reject_shadow';
    private const STATE_EXPIRED_SHADOW      = 'expired_shadow';

    // ── Route constants ───────────────────────────────────────────────────────
    private const ROUTE_NONE  = 'none';
    private const ROUTE_DEMO  = 'demo';
    private const ROUTE_LIVE  = 'live';

    /** All terminal states — no further lifecycle transitions once reached. */
    private const FINAL_STATES = [
        self::STATE_APPROVE_DEMO_SHADOW,
        self::STATE_APPROVE_LIVE_SHADOW,
        self::STATE_REJECT_SHADOW,
        self::STATE_EXPIRED_SHADOW,
    ];

    // ── Properties ───────────────────────────────────────────────────────────
    private string $moduleDir;
    private string $repoRoot;
    private array  $config;

    // ── Constructor ───────────────────────────────────────────────────────────

    public function __construct(string $moduleDir, array $config)
    {
        $this->moduleDir = rtrim($moduleDir, '/');
        $this->repoRoot  = dirname($this->moduleDir, 2);
        $this->config    = $config;
    }

    // =========================================================================
    // Public entry point
    // =========================================================================

    /**
     * Execute one Governor tick.
     *
     * @return array  last_run summary
     */
    public function run(): array
    {
        $startedAt = date('Y-m-d H:i:s');
        $errors    = [];

        // ── Counters ──────────────────────────────────────────────────────────
        $strategiesSeen              = 0;
        $signalsSeen                 = 0;
        $normalizedTotal             = 0;
        $invalidTotal                = 0;
        $staleTotal                  = 0;
        $decisionsTotal              = 0;
        $approvedDemoShadow          = 0;
        $approvedLiveShadow          = 0;
        $rejectedShadow              = 0;
        $expiredShadow               = 0;
        $waitingConfirmation         = 0;
        $corridorPending             = 0;
        $defaultImmediateDecisions   = 0;
        $decisionsWritten            = 0;
        $finalDecisionsTotal         = 0;
        $pendingTotalForRun          = 0;
        $newPending                  = [];
        $decisionsBatch              = [];
        // Phase 3A: approved demo queue counters
        $queueEnabled                = false;
        $queueMode                   = 'shadow_bridge';
        $queueTotal                  = 0;
        $queueAdded                  = 0;
        $queueSkippedInvalid         = 0;
        $queueSkippedStale           = 0;
        $queueDeduped                = 0;
        $queueLimited                = 0;
        // Legacy missing_mode retry counters
        $legacyMissingModeRetried    = 0;
        $legacyMissingModeRecovered  = 0;
        // Strategy operational mode → execution mode mapping counters
        $strategyModeMappedToDemo    = 0;
        $invalidExecutionMode        = 0;
        // Learning quality counters (populated after buildStrategyStats)
        $lqEnabled              = false;
        $lqSeenTotal            = 0;
        $lqPrimaryTotal         = 0;
        $lqSecondaryTotal       = 0;
        $lqExcludedTotal        = 0;
        $lqExchangeDisappearedTotal = 0;
        $lqUnknownSourceTotal   = 0;
        $lqEstimatedCloseTotal  = 0;
        $lqTooOldTotal          = 0;
        $lqStratsWithPrimary    = 0;
        $lqStratsOnlySecondary  = 0;

        try {
            // ── 1. Load config values ─────────────────────────────────────────
            $globalMaxTicks     = max(0, (int)($this->config['pending_confirmation_ticks']      ?? 0));
            $stratPolicies      = is_array($this->config['strategy_policies'] ?? null)
                                    ? $this->config['strategy_policies']
                                    : [];
            $minClosed          = (int)($this->config['min_closed_trades_for_live']            ?? 20);
            $minHourly          = (int)($this->config['min_hourly_trades_for_live']            ?? 5);
            // Learning quality config
            $lqEnabled          = (bool)($this->config['learning_quality_enabled']                       ?? true);
            $lqPrimarySources   = (array)($this->config['primary_learning_close_sources']               ?? ['profit_manager', 'stop_manager']);
            $lqSecondarySources = (array)($this->config['secondary_learning_close_sources']             ?? ['exchange_disappeared', 'unknown']);
            $lqExclEstimated    = (bool)($this->config['exclude_estimated_closes_from_primary']          ?? true);
            $lqExclDisappeared  = (bool)($this->config['exclude_exchange_disappeared_from_primary']      ?? true);
            $lqExclPosGone      = (bool)($this->config['exclude_position_gone_from_exchange_from_primary'] ?? true);
            $lqMaxAgeDays       = max(1, (int)($this->config['max_trade_age_days_for_primary_learning']  ?? 3));
            $minPrimaryForLive  = (int)($this->config['min_primary_closed_trades_for_live']              ?? $minClosed);
            // Use primary threshold as the live gate minimum
            $minClosed          = $minPrimaryForLive;
            $minWinrate         = (float)($this->config['min_winrate_for_live']                ?? 0.55);
            $minAvgRoi          = (float)($this->config['min_avg_roi_for_live']                ?? 1.0);
            $maxConsecLosses    = (int)($this->config['max_consecutive_losses_live']           ?? 3);
            $mode               = (string)($this->config['mode']                               ?? 'shadow');
            $maxSignalAge       = (int)($this->config['max_signal_age_seconds']                ?? 1800);
            $maxPendingAge      = (int)($this->config['max_pending_age_seconds']               ?? 3600);
            $keepFinalInPending = (bool)($this->config['keep_final_decisions_in_pending']      ?? true);
            $finalDecisionTtl   = (int)($this->config['final_decision_ttl_seconds']           ?? 86400);
            // Phase 3A queue config
            $queueEnabled       = (bool)($this->config['approved_demo_queue_enabled']         ?? true);
            $queueMode          = (string)($this->config['approved_demo_queue_mode']          ?? 'shadow_bridge');
            $maxPerRun          = max(1, (int)($this->config['max_approved_demo_per_run']     ?? 10));
            $demoTtl            = max(60, (int)($this->config['approved_demo_ttl_seconds']    ?? 1800));

            // ── 2. Discover strategies ────────────────────────────────────────
            $strategyIds = $this->discoverStrategies();

            // ── 3. Build stats from closed trades ────────────────────────────
            $closedTrades  = $this->loadClosedTrades();
            $statsResult   = $this->buildStrategyStats(
                $closedTrades,
                $lqEnabled, $lqPrimarySources, $lqSecondarySources,
                $lqExclEstimated, $lqExclDisappeared, $lqExclPosGone, $lqMaxAgeDays
            );
            $stratStats    = $statsResult['stats'];
            $lqCounters    = $statsResult['counters'];
            // Unpack learning quality counters
            $lqSeenTotal                = $lqCounters['closed_trades_seen_total'];
            $lqPrimaryTotal             = $lqCounters['closed_trades_primary_total'];
            $lqSecondaryTotal           = $lqCounters['closed_trades_secondary_total'];
            $lqExcludedTotal            = $lqCounters['closed_trades_excluded_total'];
            $lqExchangeDisappearedTotal = $lqCounters['closed_trades_exchange_disappeared_total'];
            $lqUnknownSourceTotal       = $lqCounters['closed_trades_unknown_source_total'];
            $lqEstimatedCloseTotal      = $lqCounters['closed_trades_estimated_close_total'];
            $lqTooOldTotal              = $lqCounters['closed_trades_too_old_for_primary_total'];
            $lqStratsWithPrimary        = $lqCounters['strategies_with_primary_stats_total'];
            $lqStratsOnlySecondary      = $lqCounters['strategies_with_only_secondary_stats_total'];
            $hourlyStats   = $this->buildHourlyStats(
                $closedTrades,
                $lqEnabled, $lqPrimarySources, $lqExclEstimated, $lqExclDisappeared, $lqExclPosGone, $lqMaxAgeDays
            );

            // ── 4. Collect active positions ───────────────────────────────────
            $activePositions = $this->loadJsonSafe(
                $this->repoRoot . '/modules/bot/storage/active_positions.json', []
            );

            // ── 5. Load pending signals (keyed by governor_signal_key) ────────
            $pendingSignals = $this->loadJsonSafe(
                $this->moduleDir . '/storage/pending_signals.json', []
            );
            if (!is_array($pendingSignals)) {
                $pendingSignals = [];
            }

            // ── 6. Compute open-positions count per strategy ──────────────────
            $openPerStrategy = [];
            if (is_array($activePositions)) {
                foreach ($activePositions as $pos) {
                    $sid = (string)($pos['strategy_id'] ?? $pos['owner_strategy'] ?? '');
                    if ($sid !== '') {
                        $openPerStrategy[$sid] = ($openPerStrategy[$sid] ?? 0) + 1;
                    }
                }
            }

            // ── 7. Collect and normalise signals from all strategies ──────────
            // Keyed by governor_signal_key so later signals win on collision.
            $normalizedSignals = [];
            foreach ($strategyIds as $stratId) {
                $strategiesSeen++;
                $rawSignals = $this->loadStrategySignals($stratId);
                foreach ($rawSignals as $raw) {
                    $signalsSeen++;
                    $norm = $this->normalizeSignal($raw, $stratId);
                    if ($norm === null) {
                        // Missing signal_id — invalid, do not create active pending entry.
                        $invalidTotal++;
                        // Generate a stable deduplication key so we do not re-journal the same
                        // raw signal on every Governor run (spam prevention).
                        // MD5 is used here purely as a cheap non-cryptographic hash to produce
                        // a short, stable fingerprint of the raw signal content.
                        $invalidKey = 'invalid:' . $stratId . ':' . substr(
                            md5(($raw['_source_file'] ?? '') . json_encode($raw, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)),
                            0, 16
                        );
                        // Journal only once — skip if already in pending as reject_shadow
                        $existingInvalid = $pendingSignals[$invalidKey] ?? null;
                        if ($existingInvalid === null || ($existingInvalid['state'] ?? '') !== self::STATE_REJECT_SHADOW) {
                            $invalidNorm = [
                                'governor_signal_key' => $invalidKey,
                                'signal_id'           => '',
                                'strategy_id'         => $stratId,
                                'symbol'              => (string)($raw['symbol']      ?? ''),
                                'side'                => (string)($raw['side']         ?? ''),
                                'mode'                => (string)($raw['mode']         ?? ''),
                                'entry_price'         => null,
                                'detected_at'         => '',
                            ];
                            $decisionsBatch[] = $this->buildDecisionRecord(
                                $invalidKey, $invalidNorm,
                                null, self::STATE_REJECT_SHADOW, self::STATE_REJECT_SHADOW,
                                self::ROUTE_NONE, 'missing_signal_id',
                                0, 0, $mode
                            );
                            $decisionsWritten++;
                            $decisionsTotal++;
                            $rejectedShadow++;
                            $nowStr = date('Y-m-d H:i:s');
                            $newPending[$invalidKey] = [
                                'governor_signal_key' => $invalidKey,
                                'signal_id'           => '',
                                'strategy_id'         => $stratId,
                                'symbol'              => (string)($raw['symbol']      ?? ''),
                                'side'                => (string)($raw['side']         ?? ''),
                                'mode'                => (string)($raw['mode']         ?? ''),
                                'entry_price'         => null,
                                'detected_at'         => '',
                                'tick_count'          => 0,
                                'max_ticks'           => 0,
                                'state'               => self::STATE_REJECT_SHADOW,
                                'reason'              => 'missing_signal_id',
                                'recommended_route'   => self::ROUTE_NONE,
                                'first_seen_at'       => $nowStr,
                                'last_seen_at'        => $nowStr,
                                'updated_at'          => $nowStr,
                            ];
                        } else {
                            // Already rejected — keep in newPending without re-journalling
                            $newPending[$invalidKey] = $existingInvalid;
                        }
                        continue;
                    }
                    $normalizedTotal++;
                    $normalizedSignals[$norm['governor_signal_key']] = $norm;
                }
            }

            $now = time();

            // ── 8. Process each current normalised signal ─────────────────────
            foreach ($normalizedSignals as $govKey => $norm) {
                $stratId  = $norm['strategy_id'];
                $existing = $pendingSignals[$govKey] ?? null;

                // ── Legacy migration: missing_mode reject → retry with inferred mode ──
                // Before the normal final-state guard, check whether this entry is a
                // legacy reject_shadow/missing_mode that was rejected before mode inference
                // was added to normalizeSignal().  Only reopen this specific combination:
                //   state = reject_shadow  +  reason = missing_mode  +  mode is empty
                // AND the current normalised signal now carries a valid (non-empty) mode.
                // All other final states are left untouched.
                if (
                    $existing !== null
                    && ($existing['state']  ?? '') === self::STATE_REJECT_SHADOW
                    && ($existing['reason'] ?? '') === 'missing_mode'
                    && (string)($existing['mode'] ?? '') === ''
                    && (string)($norm['mode'] ?? '') !== ''
                ) {
                    $legacyMissingModeRetried++;
                    $nowStr = date('Y-m-d H:i:s');

                    // Age check: do not recover stale signals
                    $detectedTsLeg = $this->parseTimestamp((string)($norm['detected_at'] ?? ''));
                    $signalAgeLeg  = ($detectedTsLeg > 0) ? ($now - $detectedTsLeg) : PHP_INT_MAX;
                    if ($signalAgeLeg > $maxSignalAge) {
                        $existing['state']        = self::STATE_REJECT_SHADOW;
                        $existing['reason']       = 'signal_too_old';
                        $existing['updated_at']   = $nowStr;
                        $existing['last_seen_at'] = $nowStr;
                        $staleTotal++;
                        $rejectedShadow++;
                        $decisionsTotal++;
                        $decisionsBatch[] = $this->buildDecisionRecord(
                            $govKey, $norm,
                            self::STATE_REJECT_SHADOW, self::STATE_REJECT_SHADOW,
                            self::STATE_REJECT_SHADOW, self::ROUTE_NONE, 'signal_too_old',
                            (int)($existing['tick_count'] ?? 0), 0, $mode
                        );
                        $decisionsWritten++;
                        $newPending[$govKey] = $existing;
                        continue;
                    }

                    // Resolve per-strategy policy for the retry
                    $legPol          = $this->resolvePolicy($stratId, $stratPolicies, $globalMaxTicks);
                    $legConfirmReq   = $legPol['confirmation_required'];
                    $legMaxTicks     = $legPol['pending_confirmation_ticks'];

                    if ($legConfirmReq) {
                        // Corridor-like strategy: restart confirmation lifecycle
                        $newLegState  = self::STATE_WAIT_CONFIRM;
                        $newLegRoute  = self::ROUTE_NONE;
                        $newLegReason = 'mode_inferred_retry';
                    } else {
                        // Immediate shadow decision using updated norm (mode now valid)
                        [$newLegState, $newLegRoute, $newLegReason] = $this->decideImmediate(
                            $norm, $stratStats[$stratId] ?? [],
                            $minClosed, $minWinrate, $minAvgRoi, $maxConsecLosses,
                            $lqEnabled
                        );
                    }

                    // Journal the recovery transition exactly once (state changes after this
                    // run, so the condition is never re-triggered for the same entry).
                    $decisionsBatch[] = $this->buildDecisionRecord(
                        $govKey, $norm,
                        self::STATE_REJECT_SHADOW, $newLegState,
                        $newLegState, $newLegRoute, 'mode_inferred_retry',
                        0, $legConfirmReq ? $legMaxTicks : 0, $mode
                    );
                    $decisionsWritten++;
                    $decisionsTotal++;

                    // Build updated pending entry
                    $pLeg                       = $existing;
                    $pLeg['mode']               = $norm['mode'];
                    $pLeg['state']              = $newLegState;
                    $pLeg['reason']             = $newLegReason;
                    $pLeg['recommended_route']  = $newLegRoute;
                    $pLeg['max_ticks']          = $legConfirmReq ? $legMaxTicks : 0;
                    $pLeg['tick_count']         = $legConfirmReq ? 1 : 0;
                    $pLeg['updated_at']         = $nowStr;
                    $pLeg['last_seen_at']       = $nowStr;
                    if (!empty($norm['mode_inferred'])) {
                        $pLeg['mode_inferred']      = true;
                        $pLeg['mode_inferred_from'] = $norm['mode_inferred_from'] ?? null;
                    }

                    // Tally per-run counters
                    match ($newLegState) {
                        self::STATE_APPROVE_DEMO_SHADOW => $approvedDemoShadow++,
                        self::STATE_APPROVE_LIVE_SHADOW => $approvedLiveShadow++,
                        self::STATE_REJECT_SHADOW       => $rejectedShadow++,
                        self::STATE_WAIT_CONFIRM        => $waitingConfirmation++,
                        default                         => null,
                    };
                    if (in_array($newLegState, [self::STATE_APPROVE_DEMO_SHADOW, self::STATE_WAIT_CONFIRM], true)) {
                        $legacyMissingModeRecovered++;
                    }

                    $newPending[$govKey] = $pLeg;
                    continue;
                }

                // ── Legacy migration: strategy operational mode → execution mode demo ──
                // Pending entries created before operational-mode filtering was added may
                // carry mode = 'passive' (or 'active'/'disabled'/'smoke_demo') even though
                // the decision already points to demo shadow.  Remap them once and journal
                // a single transition so the UI and shadow_compare see a clean 'demo' mode.
                static $legacyOperationalModes = ['passive', 'active', 'disabled', 'smoke_demo'];
                if (
                    $existing !== null
                    && in_array($existing['mode'] ?? '', $legacyOperationalModes, true)
                    && in_array($existing['state'] ?? '', [self::STATE_APPROVE_DEMO_SHADOW, self::STATE_WAIT_CONFIRM], true)
                    && ($norm['mode'] ?? '') === 'demo'
                ) {
                    $strategyModeMappedToDemo++;
                    $nowStr  = date('Y-m-d H:i:s');
                    $oldMode = (string)($existing['mode']);

                    $pPassive                     = $existing;
                    $pPassive['mode']             = 'demo';
                    $pPassive['mode_inferred']    = true;
                    $pPassive['mode_inferred_from'] = 'strategy_mode_mapped_to_demo';
                    $pPassive['updated_at']       = $nowStr;
                    $pPassive['last_seen_at']     = $nowStr;
                    if (($pPassive['strategy_runtime_mode'] ?? '') === '') {
                        $pPassive['strategy_runtime_mode'] = $oldMode;
                    }

                    // Journal this remap exactly once — mode changes so it won't re-trigger
                    $decisionsBatch[] = $this->buildDecisionRecord(
                        $govKey, $norm,
                        ($existing['state'] ?? ''), ($existing['state'] ?? ''),
                        ($existing['state'] ?? ''), ($existing['recommended_route'] ?? self::ROUTE_NONE),
                        'strategy_mode_mapped_to_demo',
                        (int)($existing['tick_count'] ?? 0),
                        (int)($existing['max_ticks']  ?? 0),
                        $mode
                    );
                    $decisionsWritten++;

                    $newPending[$govKey] = $pPassive;
                    continue;
                }

                // Already reached a terminal state — keep as-is, no re-processing
                if ($existing !== null && in_array($existing['state'] ?? '', self::FINAL_STATES, true)) {
                    $newPending[$govKey] = $existing;
                    continue;
                }

                // ── Stale signal check ────────────────────────────────────────
                $detectedAt = (string)($norm['detected_at']);
                $detectedTs = $this->parseTimestamp($detectedAt);
                $signalAge = ($detectedTs > 0) ? ($now - $detectedTs) : PHP_INT_MAX;

                if ($signalAge > $maxSignalAge) {
                    $staleTotal++;
                    $prevState = $existing['state'] ?? null;
                    // Only journal on state change — avoids repeat-reject spam
                    if ($prevState !== self::STATE_REJECT_SHADOW) {
                        $decisionsBatch[] = $this->buildDecisionRecord(
                            $govKey, $norm, $prevState,
                            self::STATE_REJECT_SHADOW, self::STATE_REJECT_SHADOW,
                            self::ROUTE_NONE, 'signal_too_old',
                            (int)($existing['tick_count'] ?? 0), 0, $mode
                        );
                        $decisionsWritten++;
                        $decisionsTotal++;
                        $rejectedShadow++;
                    }
                    $pEntry                  = $existing ?? $this->initPendingEntry($norm);
                    $pEntry['state']         = self::STATE_REJECT_SHADOW;
                    $pEntry['reason']        = 'signal_too_old';
                    $pEntry['updated_at']    = date('Y-m-d H:i:s');
                    $pEntry['last_seen_at']  = date('Y-m-d H:i:s');
                    $newPending[$govKey]     = $pEntry;
                    continue;
                }

                // ── Resolve per-strategy confirmation policy ──────────────────
                $policy          = $this->resolvePolicy($stratId, $stratPolicies, $globalMaxTicks);
                $confirmRequired = $policy['confirmation_required'];
                $maxTicks        = $policy['pending_confirmation_ticks'];

                // Initialise or retrieve pending entry
                $pEntry                 = $existing ?? $this->initPendingEntry($norm);
                $pEntry['last_seen_at'] = date('Y-m-d H:i:s');
                $pEntry['max_ticks']    = $maxTicks;
                $prevState              = $pEntry['state'] ?? null;

                if (!$confirmRequired) {
                    // ── Immediate shadow decision ─────────────────────────────
                    $defaultImmediateDecisions++;
                    [$decision, $route, $reason] = $this->decideImmediate(
                        $norm, $stratStats[$stratId] ?? [],
                        $minClosed, $minWinrate, $minAvgRoi, $maxConsecLosses,
                        $lqEnabled
                    );
                    $decisionsTotal++;
                    $pEntry['state']             = $decision;
                    $pEntry['reason']            = $reason;
                    $pEntry['updated_at']        = date('Y-m-d H:i:s');
                    $pEntry['recommended_route'] = $route;

                    // Journal only on state change — avoids re-writing same entry every run
                    if ($prevState !== $decision) {
                        $decisionsBatch[] = $this->buildDecisionRecord(
                            $govKey, $norm, $prevState, $decision,
                            $decision, $route, $reason, 0, 0, $mode
                        );
                        $decisionsWritten++;
                    }

                    match ($decision) {
                        self::STATE_APPROVE_DEMO_SHADOW => $approvedDemoShadow++,
                        self::STATE_APPROVE_LIVE_SHADOW => $approvedLiveShadow++,
                        self::STATE_REJECT_SHADOW       => $rejectedShadow++,
                        default                         => null,
                    };
                    if ($reason === 'invalid_execution_mode') {
                        $invalidExecutionMode++;
                    }
                    $newPending[$govKey] = $pEntry;

                } else {
                    // ── Confirmation-required lifecycle ───────────────────────
                    $currentState = $pEntry['state'] ?? null;

                    // Only advance if not already in a final state
                    if (!in_array($currentState, self::FINAL_STATES, true)) {
                        $pEntry['tick_count'] = (int)($pEntry['tick_count'] ?? 0) + 1;
                        $tickCount            = $pEntry['tick_count'];
                        $pEntry['updated_at'] = date('Y-m-d H:i:s');

                        // Per-tick hard-reject check (signal validity during window)
                        $hardRejectReason = $this->checkHardReject($norm, $maxSignalAge);

                        if ($hardRejectReason !== null) {
                            // Hard reject during confirmation window
                            $pEntry['state']  = self::STATE_REJECT_SHADOW;
                            $pEntry['reason'] = $hardRejectReason;
                            $rejectedShadow++;
                            if ($hardRejectReason === 'invalid_execution_mode') {
                                $invalidExecutionMode++;
                            }
                            $decisionsTotal++;
                            $decisionsBatch[] = $this->buildDecisionRecord(
                                $govKey, $norm, $currentState,
                                self::STATE_REJECT_SHADOW, self::STATE_REJECT_SHADOW,
                                self::ROUTE_NONE, $hardRejectReason,
                                $tickCount, $maxTicks, $mode
                            );
                            $decisionsWritten++;

                        } elseif ($tickCount < $maxTicks) {
                            // Still accumulating confirmation ticks
                            $pEntry['state'] = self::STATE_WAIT_CONFIRM;
                            $waitingConfirmation++;
                            if ($stratId === 'corridor_bottom_long') {
                                $corridorPending++;
                            }
                            // Journal on first observation or each tick advance
                            $isNew = ($prevState === null || $prevState === '');
                            if ($isNew || $currentState === self::STATE_WAIT_CONFIRM) {
                                $decisionsBatch[] = $this->buildDecisionRecord(
                                    $govKey, $norm, $prevState,
                                    self::STATE_WAIT_CONFIRM, self::STATE_WAIT_CONFIRM,
                                    self::ROUTE_NONE, 'pending_confirmation_tick',
                                    $tickCount, $maxTicks, $mode
                                );
                                $decisionsWritten++;
                            }

                        } else {
                            // Confirmation window complete — make final decision
                            [$decision, $route, $reason] = $this->decideImmediate(
                                $norm, $stratStats[$stratId] ?? [],
                                $minClosed, $minWinrate, $minAvgRoi, $maxConsecLosses,
                                $lqEnabled
                            );
                            $pEntry['state']             = $decision;
                            $pEntry['reason']            = $reason;
                            $pEntry['recommended_route'] = $route;
                            $decisionsTotal++;

                            $decisionsBatch[] = $this->buildDecisionRecord(
                                $govKey, $norm, self::STATE_WAIT_CONFIRM, $decision,
                                $decision, $route, $reason,
                                $tickCount, $maxTicks, $mode
                            );
                            $decisionsWritten++;

                            match ($decision) {
                                self::STATE_APPROVE_DEMO_SHADOW => $approvedDemoShadow++,
                                self::STATE_APPROVE_LIVE_SHADOW => $approvedLiveShadow++,
                                self::STATE_REJECT_SHADOW       => $rejectedShadow++,
                                default                         => null,
                            };
                            if ($reason === 'invalid_execution_mode') {
                                $invalidExecutionMode++;
                            }
                        }
                    }
                    $newPending[$govKey] = $pEntry;
                }
            }

            // ── 9. Handle pending signals NOT in the current batch ────────────
            // These are signals that disappeared from strategy storage this run.
            foreach ($pendingSignals as $govKey => $pEntry) {
                if (isset($normalizedSignals[$govKey]) || isset($newPending[$govKey])) {
                    // Already handled above
                    continue;
                }

                $pState    = $pEntry['state'] ?? '';
                $firstSeen = $this->parseTimestamp((string)($pEntry['first_seen_at'] ?? ''));

                if (in_array($pState, self::FINAL_STATES, true)) {
                    // Final state — keep for TTL cleanup pass
                    $newPending[$govKey] = $pEntry;
                } elseif ($firstSeen > 0 && ($now - $firstSeen) > $maxPendingAge) {
                    // Signal disappeared and pending window exceeded → expire
                    $expiredShadow++;
                    $decisionsTotal++;
                    $pEntry['state']      = self::STATE_EXPIRED_SHADOW;
                    $pEntry['reason']     = 'signal_disappeared_pending_expired';
                    $pEntry['updated_at'] = date('Y-m-d H:i:s');

                    $decisionsBatch[] = $this->buildDecisionRecord(
                        $govKey,
                        [
                            'governor_signal_key' => $govKey,
                            'signal_id'           => $pEntry['signal_id']   ?? '',
                            'strategy_id'         => $pEntry['strategy_id'] ?? '',
                            'symbol'              => $pEntry['symbol']      ?? '',
                            'side'                => $pEntry['side']        ?? '',
                            'mode'                => $pEntry['mode']        ?? '',
                            'entry_price'         => $pEntry['entry_price'] ?? null,
                            'detected_at'         => $pEntry['detected_at'] ?? '',
                        ],
                        $pState, self::STATE_EXPIRED_SHADOW,
                        self::STATE_EXPIRED_SHADOW, self::ROUTE_NONE,
                        'signal_disappeared_pending_expired',
                        (int)($pEntry['tick_count'] ?? 0),
                        (int)($pEntry['max_ticks']  ?? 0),
                        $mode
                    );
                    $decisionsWritten++;
                    $newPending[$govKey] = $pEntry;
                } else {
                    // Not yet expired — keep pending (will be re-evaluated next tick)
                    $newPending[$govKey] = $pEntry;
                }
            }

            // ── 10. TTL cleanup for final decisions ───────────────────────────
            $cutoff = $now - $finalDecisionTtl;
            foreach (array_keys($newPending) as $govKey) {
                $pEntry = $newPending[$govKey];
                if (!in_array($pEntry['state'] ?? '', self::FINAL_STATES, true)) {
                    continue;
                }
                if (!$keepFinalInPending) {
                    unset($newPending[$govKey]);
                    continue;
                }
                $updatedTs = $this->parseTimestamp((string)($pEntry['updated_at'] ?? $pEntry['first_seen_at'] ?? ''));
                if ($updatedTs > 0 && $updatedTs < $cutoff) {
                    unset($newPending[$govKey]);
                }
            }

            // ── 11. Tally pending stats ───────────────────────────────────────
            $pendingTotalForRun = count($newPending);
            // Per-run transition counters
            foreach ($newPending as $pEntry) {
                if (in_array($pEntry['state'] ?? '', self::FINAL_STATES, true)) {
                    $finalDecisionsTotal++;
                }
            }
            // Current-state snapshot counters (reflect actual state of pending_signals.json)
            $currPendingTotal        = count($newPending);
            $currWaitConfirmation    = 0;
            $currApprovedDemoShadow  = 0;
            $currApprovedLiveShadow  = 0;
            $currRejectedShadow      = 0;
            $currExpiredShadow       = 0;
            $currFinalDecisions      = 0;
            foreach ($newPending as $pEntry) {
                $s = $pEntry['state'] ?? '';
                match ($s) {
                    self::STATE_WAIT_CONFIRM        => $currWaitConfirmation++,
                    self::STATE_APPROVE_DEMO_SHADOW => $currApprovedDemoShadow++,
                    self::STATE_APPROVE_LIVE_SHADOW => $currApprovedLiveShadow++,
                    self::STATE_REJECT_SHADOW       => $currRejectedShadow++,
                    self::STATE_EXPIRED_SHADOW      => $currExpiredShadow++,
                    default                         => null,
                };
                if (in_array($s, self::FINAL_STATES, true)) {
                    $currFinalDecisions++;
                }
            }

            // ── 12. Persist state files ───────────────────────────────────────
            $this->savePendingSignals($newPending);
            $this->saveStrategyStats(
                $stratStats, $openPerStrategy, $strategyIds,
                $minClosed, $minWinrate, $minAvgRoi, $maxConsecLosses
            );
            $this->saveHourlyStats($hourlyStats);
            $this->appendDecisions($decisionsBatch);

            // ── 13. Phase 3A: build approved demo queue ───────────────────────
            $queuePath     = $this->moduleDir . '/storage/approved_demo_queue.json';
            $existingQueue = $this->loadJsonSafe($queuePath, []);
            if (!is_array($existingQueue)) {
                $existingQueue = [];
            }

            // Index existing queue entries by governor_signal_key for O(1) dedup lookup
            $existingQueueByKey = [];
            foreach ($existingQueue as $qItem) {
                $k = (string)($qItem['governor_signal_key'] ?? '');
                if ($k !== '') {
                    $existingQueueByKey[$k] = $qItem;
                }
            }

            $newQueue          = [];   // keyed by governor_signal_key
            $queueJournalBatch = [];

            if ($queueEnabled) {
                foreach ($newPending as $govKey => $pEntry) {
                    // Only process approve_demo_shadow + demo route entries
                    if (($pEntry['state']              ?? '') !== self::STATE_APPROVE_DEMO_SHADOW
                        || ($pEntry['recommended_route'] ?? '') !== self::ROUTE_DEMO
                    ) {
                        continue;
                    }

                    // Build a pseudo-norm for validateSignalBasic (pending entry has all required fields).
                    // For approve_demo_shadow signals with recommended_route=demo, mode may be absent in
                    // the pending record — normalise it to 'demo' so the basic validator does not reject.
                    // This is safe because we are inside the filter:
                    //   state === STATE_APPROVE_DEMO_SHADOW && recommended_route === ROUTE_DEMO  (line 523–526)
                    $pMode = (string)($pEntry['mode'] ?? '');
                    if ($pMode === '') {
                        $pMode = 'demo'; // normalised: recommended_route is already confirmed to be ROUTE_DEMO
                    }
                    $pseudoNorm = [
                        'governor_signal_key' => $govKey,
                        'signal_id'           => $pEntry['signal_id']   ?? '',
                        'strategy_id'         => $pEntry['strategy_id'] ?? '',
                        'symbol'              => $pEntry['symbol']       ?? '',
                        'side'                => $pEntry['side']         ?? '',
                        'mode'                => $pMode,
                        'entry_price'         => $pEntry['entry_price']  ?? null,
                        'detected_at'         => $pEntry['detected_at']  ?? '',
                        'handoff_valid'       => null, // not stored in pending; treated as unset
                    ];

                    // Basic signal validity check
                    if ($this->validateSignalBasic($pseudoNorm) !== null) {
                        $queueSkippedInvalid++;
                        continue;
                    }

                    // Age check: signal must not be older than the demo TTL
                    $detectedTs = $this->parseTimestamp((string)($pEntry['detected_at'] ?? ''));
                    if ($detectedTs > 0 && ($now - $detectedTs) > $demoTtl) {
                        $queueSkippedStale++;
                        continue;
                    }

                    // Deduplication: already in queue from a previous run
                    if (isset($existingQueueByKey[$govKey])) {
                        $carried                   = $existingQueueByKey[$govKey];
                        $carried['last_seen_at']   = date('Y-m-d H:i:s');
                        $newQueue[$govKey]          = $carried;
                        $queueDeduped++;
                        continue;
                    }

                    // Per-run limit
                    if ($queueAdded >= $maxPerRun) {
                        $queueLimited++;
                        continue;
                    }

                    // Build new queue item
                    $approvedAt   = (string)($pEntry['updated_at'] ?? $pEntry['last_seen_at'] ?? date('Y-m-d H:i:s'));
                    $approvedTs   = $this->parseTimestamp($approvedAt);
                    $ttlExpiresAt = date('Y-m-d H:i:s', ($approvedTs > 0 ? $approvedTs : $now) + $demoTtl);

                    // Pull extra fields from the normalised signal if it is still available
                    $norm = $normalizedSignals[$govKey] ?? null;

                    $newQueue[$govKey] = [
                        'governor_queue_id'   => 'gq_' . substr(md5($govKey . $approvedAt), 0, 12),
                        'governor_signal_key' => $govKey,
                        'signal_id'           => $pEntry['signal_id']   ?? '',
                        'strategy_id'         => $pEntry['strategy_id'] ?? '',
                        'symbol'              => $pEntry['symbol']       ?? '',
                        'side'                => $pEntry['side']         ?? '',
                        'mode'                => $pMode,           // from pending record; empty → 'demo' (see normalization above)
                        'entry_price'         => $pEntry['entry_price']  ?? null,
                        'entry_mode'          => $norm['entry_mode']     ?? null,
                        'entry_type'          => $norm['entry_type']     ?? null,
                        'detected_at'         => $pEntry['detected_at']  ?? '',
                        'created_at'          => $pEntry['first_seen_at'] ?? '',
                        'approved_at'         => $approvedAt,
                        'last_seen_at'        => date('Y-m-d H:i:s'),
                        'decision_id'         => '',
                        'source'              => $norm ? ($norm['source']      ?? '') : '',
                        'source_file'         => $norm ? ($norm['source_file'] ?? '') : '',
                        'governor_reason'     => $pEntry['reason'] ?? '',
                        'governor_state'      => $pEntry['state']  ?? '',
                        'ttl_expires_at'      => $ttlExpiresAt,
                    ];
                    $queueAdded++;

                    // Journal one event per new queue addition (no repeat spam)
                    $queueJournalBatch[] = $this->buildDecisionRecord(
                        $govKey, $pseudoNorm,
                        self::STATE_APPROVE_DEMO_SHADOW, 'approved_demo_queued_shadow',
                        'approved_demo_queued_shadow', self::ROUTE_DEMO,
                        'governor_demo_queue_shadow_bridge',
                        (int)($pEntry['tick_count'] ?? 0), (int)($pEntry['max_ticks'] ?? 0),
                        $mode
                    );
                }
            }

            $queueTotal = count($newQueue);
            $this->appendDecisions($queueJournalBatch);
            // Save as a flat array (values only, no associative key export)
            $this->writeJsonFile($queuePath, array_values($newQueue));

        } catch (\Throwable $ex) {
            $errors[] = $ex->getMessage();
        }

        $finishedAt = date('Y-m-d H:i:s');
        $summary = [
            'started_at'                        => $startedAt,
            'finished_at'                       => $finishedAt,
            'status'                            => empty($errors) ? 'completed' : 'completed_with_errors',
            'mode'                              => $this->config['mode'] ?? 'shadow',
            'strategies_seen'                   => $strategiesSeen,
            'signals_seen'                      => $signalsSeen,
            'normalized_signals_total'          => $normalizedTotal,
            'invalid_signals_total'             => $invalidTotal,
            'stale_signals_total'               => $staleTotal,
            'pending_total'                     => $pendingTotalForRun,
            'waiting_confirmation_total'        => $waitingConfirmation,
            'approved_demo_shadow_total'        => $approvedDemoShadow,
            'approved_live_shadow_total'        => $approvedLiveShadow,
            'rejected_shadow_total'             => $rejectedShadow,
            'expired_shadow_total'              => $expiredShadow,
            'final_decisions_total'             => $finalDecisionsTotal,
            'decisions_written_total'           => $decisionsWritten,
            'decisions_total'                   => $decisionsTotal,
            'corridor_pending_total'            => $corridorPending,
            'default_immediate_decisions_total' => $defaultImmediateDecisions,
            // ── Current snapshot (what exists in pending_signals.json right now) ──
            'current_pending_total'             => $currPendingTotal       ?? 0,
            'current_wait_confirmation_total'   => $currWaitConfirmation   ?? 0,
            'current_approved_demo_shadow_total'=> $currApprovedDemoShadow ?? 0,
            'current_approved_live_shadow_total'=> $currApprovedLiveShadow ?? 0,
            'current_rejected_shadow_total'     => $currRejectedShadow     ?? 0,
            'current_expired_shadow_total'      => $currExpiredShadow      ?? 0,
            'current_final_decisions_total'     => $currFinalDecisions     ?? 0,
            // ── Phase 3A: approved demo queue ──────────────────────────────────
            'approved_demo_queue_enabled'       => $queueEnabled,
            'approved_demo_queue_mode'          => $queueMode,
            'approved_demo_queue_total'         => $queueTotal,
            'approved_demo_queue_added'         => $queueAdded,
            'approved_demo_queue_skipped_invalid' => $queueSkippedInvalid,
            'approved_demo_queue_skipped_stale' => $queueSkippedStale,
            'approved_demo_queue_deduped'       => $queueDeduped,
            'approved_demo_queue_limited'       => $queueLimited,
            // ── Legacy missing_mode retry ─────────────────────────────────────
            'governor_legacy_missing_mode_retried_total'   => $legacyMissingModeRetried,
            'governor_legacy_missing_mode_recovered_total' => $legacyMissingModeRecovered,
            // ── Strategy operational mode → execution mode mapping ────────────
            'governor_strategy_mode_mapped_to_demo_total'  => $strategyModeMappedToDemo,
            'governor_invalid_execution_mode_total'        => $invalidExecutionMode,
            // ── Learning data quality ─────────────────────────────────────────
            'learning_quality_enabled'                    => $lqEnabled,
            'closed_trades_seen_total'                    => $lqSeenTotal,
            'closed_trades_primary_total'                 => $lqPrimaryTotal,
            'closed_trades_secondary_total'               => $lqSecondaryTotal,
            'closed_trades_excluded_total'                => $lqExcludedTotal,
            'closed_trades_exchange_disappeared_total'    => $lqExchangeDisappearedTotal,
            'closed_trades_unknown_source_total'          => $lqUnknownSourceTotal,
            'closed_trades_estimated_close_total'         => $lqEstimatedCloseTotal,
            'closed_trades_too_old_for_primary_total'     => $lqTooOldTotal,
            'strategies_with_primary_stats_total'         => $lqStratsWithPrimary,
            'strategies_with_only_secondary_stats_total'  => $lqStratsOnlySecondary,
            'errors'                            => $errors,
        ];

        $this->writeJsonFile($this->moduleDir . '/storage/last_run.json', $summary);

        return $summary;
    }

    // =========================================================================
    // Signal normalisation
    // =========================================================================

    /**
     * Normalise a raw strategy signal into the canonical internal structure.
     *
     * Returns null if signal_id is missing (the signal is considered invalid
     * and must not create a pending lifecycle entry).
     */
    private function normalizeSignal(array $raw, string $stratId): ?array
    {
        $signalId = (string)($raw['signal_id'] ?? $raw['id'] ?? '');
        if ($signalId === '') {
            return null;
        }

        $govKey     = $stratId . ':' . $signalId;
        $sourceFile = (string)($raw['_source_file'] ?? '');

        // ── Mode normalisation with safe demo inference ───────────────────────
        // Valid execution modes Governor may write into a pending entry.
        static $validExecutionModes = ['demo', 'paper'];
        // Strategy operational/lifecycle modes — these describe how a strategy runs
        // (e.g. passive = no new positions, active = normal) but are NOT bot execution
        // modes.  Governor must never use them as the 'mode' field of a signal.
        static $operationalModes = ['passive', 'active', 'disabled', 'smoke_demo'];

        $rawMode             = (string)($raw['mode'] ?? $raw['execution_mode'] ?? '');
        $strategyRuntimeMode = null;
        $mode                = '';
        $modeInferred        = false;
        $modeInferredFrom    = null;

        // Classify the raw mode field from the incoming signal.
        if (in_array($rawMode, $operationalModes, true)) {
            // Operational mode (e.g. "passive") — store as strategy_runtime_mode;
            // execution mode must still be inferred below.
            $strategyRuntimeMode = $rawMode;
        } elseif ($rawMode === 'live') {
            // Never infer live from a signal field — treat as missing/unsafe.
        } elseif (in_array($rawMode, $validExecutionModes, true)) {
            // Valid execution mode supplied directly by the signal.
            $mode = $rawMode;
        }
        // else: unrecognised or empty value — fall through to inference.

        if ($mode === '') {
            // 1. Source file is a bot_handoff_queue → infer demo (handoff context)
            if ($sourceFile !== '' && str_contains($sourceFile, 'bot_handoff_queue')) {
                $mode             = 'demo';
                $modeInferred     = true;
                $modeInferredFrom = 'handoff_context';
            }

            // 2. Try strategy active/base config for the mode key
            if ($mode === '') {
                $stratConfigMode = $this->readStrategyConfigMode($stratId);
                if (in_array($stratConfigMode, $operationalModes, true)) {
                    // Config has an operational mode (e.g. "passive") — record it as
                    // strategy_runtime_mode and safely infer demo for execution.
                    if ($strategyRuntimeMode === null) {
                        $strategyRuntimeMode = $stratConfigMode;
                    }
                    $mode             = 'demo';
                    $modeInferred     = true;
                    $modeInferredFrom = 'config_operational_mode';
                } elseif (in_array($stratConfigMode, $validExecutionModes, true)) {
                    $mode             = $stratConfigMode;
                    $modeInferred     = true;
                    $modeInferredFrom = 'strategy_config';
                }
            }

            // 3. Default to demo for any known strategy handoff signal — never live.
            if ($mode === '') {
                $mode             = 'demo';
                $modeInferred     = true;
                $modeInferredFrom = 'default_demo';
            }
        }

        return [
            'governor_signal_key'  => $govKey,
            'signal_id'            => $signalId,
            'strategy_id'          => $stratId,
            'symbol'               => (string)($raw['symbol']      ?? ''),
            'side'                 => (string)($raw['side']         ?? ''),
            'mode'                 => $mode,
            'strategy_runtime_mode'=> $strategyRuntimeMode,
            'mode_inferred'        => $modeInferred,
            'mode_inferred_from'   => $modeInferredFrom,
            'entry_price'          => $raw['entry_price'] ?? $raw['price'] ?? null,
            'detected_at'          => (string)($raw['detected_at']  ?? $raw['created_at'] ?? ''),
            'created_at'           => (string)($raw['created_at']   ?? $raw['detected_at'] ?? ''),
            'source'               => $sourceFile !== '' ? basename($sourceFile) : '',
            'source_file'          => $sourceFile,
            'handoff_valid'        => $raw['handoff_valid'] ?? null,
        ];
    }

    /**
     * Read the 'mode' key from a strategy's active.php or base.php config.
     *
     * Returns '' if the config cannot be loaded or produces no mode value.
     * Never returns 'live' — callers must not infer live from this helper.
     */
    private function readStrategyConfigMode(string $stratId): string
    {
        $configDir = $this->repoRoot . '/modules/strategy/pattern/' . $stratId . '/config';
        foreach (['active.php', 'base.php'] as $file) {
            $path = $configDir . '/' . $file;
            if (!is_file($path)) {
                continue;
            }
            try {
                $cfg = @include $path;
                if (is_array($cfg)) {
                    $cfgMode = (string)($cfg['mode'] ?? $cfg['execution_mode'] ?? '');
                    if ($cfgMode !== '' && $cfgMode !== 'live') {
                        return $cfgMode;
                    }
                }
            } catch (\Throwable) {
                // Ignore config read failures — never crash over missing config
            }
        }
        return '';
    }

    // =========================================================================
    // Policy resolver
    // =========================================================================

    /**
     * Resolve per-strategy confirmation policy.
     *
     * Priority: strategy_policies[strategy_id] > strategy_policies['default'] > safe fallback.
     */
    private function resolvePolicy(string $stratId, array $policies, int $globalFallback): array
    {
        $pol = $policies[$stratId] ?? $policies['default'] ?? null;

        if ($pol !== null && is_array($pol)) {
            $req   = (bool)($pol['confirmation_required']     ?? false);
            $ticks = (int)($pol['pending_confirmation_ticks'] ?? ($req ? $globalFallback : 0));
            return [
                'confirmation_required'      => $req,
                'pending_confirmation_ticks' => $req ? max(1, $ticks) : 0,
            ];
        }

        return ['confirmation_required' => false, 'pending_confirmation_ticks' => 0];
    }

    // =========================================================================
    // Pending entry factory
    // =========================================================================

    /** Initialise a fresh pending entry from a normalised signal. */
    private function initPendingEntry(array $norm): array
    {
        $now = date('Y-m-d H:i:s');
        $entry = [
            'governor_signal_key' => $norm['governor_signal_key'],
            'signal_id'           => $norm['signal_id'],
            'strategy_id'         => $norm['strategy_id'],
            'symbol'              => $norm['symbol'],
            'side'                => $norm['side'],
            'mode'                => $norm['mode'],
            'entry_price'         => $norm['entry_price'],
            'detected_at'         => $norm['detected_at'],
            'tick_count'          => 0,
            'max_ticks'           => 0,
            'state'               => null,
            'reason'              => null,
            'recommended_route'   => null,
            'first_seen_at'       => $now,
            'last_seen_at'        => $now,
            'updated_at'          => $now,
        ];
        // Propagate mode inference diagnostics when mode was inferred
        if (!empty($norm['mode_inferred'])) {
            $entry['mode_inferred']      = true;
            $entry['mode_inferred_from'] = $norm['mode_inferred_from'] ?? null;
        }
        // Propagate strategy operational/runtime mode when present
        if (($norm['strategy_runtime_mode'] ?? null) !== null) {
            $entry['strategy_runtime_mode'] = $norm['strategy_runtime_mode'];
        }
        return $entry;
    }

    // =========================================================================
    // Basic signal validation (shared)
    // =========================================================================

    /**
     * Perform basic validity checks that apply to any normalised signal.
     *
     * Checks: symbol, entry_price > 0, detected_at, side (empty or "long"),
     * mode, handoff_valid not false.
     *
     * Returns the rejection reason string, or null if the signal is valid.
     */
    private function validateSignalBasic(array $norm): ?string
    {
        if ((string)($norm['symbol'] ?? '') === '') {
            return 'missing_symbol';
        }
        $ep = $norm['entry_price'] ?? null;
        if ($ep === null || (float)$ep <= 0.0) {
            return 'missing_entry_price';
        }
        if ((string)($norm['detected_at'] ?? '') === '') {
            return 'missing_detected_at';
        }
        $side = (string)($norm['side'] ?? '');
        if ($side !== '' && $side !== 'long') {
            return 'side_not_long';
        }
        if ((string)($norm['mode'] ?? '') === '') {
            return 'missing_mode';
        }
        // Only demo and paper are valid execution modes for Governor.
        static $validExecModes = ['demo', 'paper'];
        if (!in_array((string)($norm['mode'] ?? ''), $validExecModes, true)) {
            return 'invalid_execution_mode';
        }
        if (isset($norm['handoff_valid']) && $norm['handoff_valid'] === false) {
            return 'handoff_signal_invalid';
        }
        return null;
    }

    // =========================================================================
    // Hard-reject conditions (used during confirmation window)
    // =========================================================================

    /**
     * Check per-tick hard-reject conditions during a confirmation window.
     *
     * Returns the reject reason string, or null if the signal still passes.
     */
    private function checkHardReject(array $norm, int $maxSignalAge): ?string
    {
        // Use the shared basic validator first
        $basicFail = $this->validateSignalBasic($norm);
        if ($basicFail !== null) {
            return $basicFail;
        }
        // Age re-check (signal may have aged out during the confirmation window)
        $detectedAt = (string)$norm['detected_at'];
        $ts = $this->parseTimestamp($detectedAt);
        if ($ts > 0 && (time() - $ts) > $maxSignalAge) {
            return 'signal_too_old';
        }
        return null;
    }

    // =========================================================================
    // Immediate shadow decision engine
    // =========================================================================

    /**
     * Decide immediately based on signal validity + strategy stats.
     *
     * When $lqEnabled is true, uses primary_closed_trades_total for the live gate
     * threshold and returns 'not_enough_primary_closed_trades' instead of
     * 'not_enough_closed_trades' when primary data is insufficient.
     *
     * In shadow mode stats can only determine the recommended route; they never
     * block the demo route entirely.
     *
     * @return array{0: string, 1: string, 2: string}  [decision, route, reason]
     */
    private function decideImmediate(
        array $norm,
        array $stats,
        int   $minClosed,
        float $minWinrate,
        float $minAvgRoi,
        int   $maxConsecLosses,
        bool  $lqEnabled = false,
    ): array {
        // ── Signal validation (shared) ────────────────────────────────────────
        $basicFail = $this->validateSignalBasic($norm);
        if ($basicFail !== null) {
            return [self::STATE_REJECT_SHADOW, self::ROUTE_NONE, $basicFail];
        }

        // ── Stats-based route gate (never rejects demo in shadow mode) ────────
        // When learning quality is enabled, use primary_closed_trades_total so
        // secondary/uncertain trades do not count towards the live threshold.
        if ($lqEnabled) {
            $closedTotal  = (int)($stats['primary']['closed_trades_total'] ?? $stats['primary_closed_trades_total'] ?? 0);
            $winrate      = (float)($stats['primary']['winrate']           ?? $stats['winrate']          ?? 0.0);
            $avgRoi       = (float)($stats['primary']['avg_roi']           ?? $stats['avg_roi']          ?? 0.0);
            $consecLosses = (int)($stats['primary']['consecutive_losses']  ?? $stats['consecutive_losses'] ?? 0);
            $insufficientReason = 'not_enough_primary_closed_trades';
        } else {
            $closedTotal  = (int)($stats['closed_trades_total'] ?? 0);
            $winrate      = (float)($stats['winrate']           ?? 0.0);
            $avgRoi       = (float)($stats['avg_roi']           ?? 0.0);
            $consecLosses = (int)($stats['consecutive_losses']  ?? 0);
            $insufficientReason = 'not_enough_closed_trades';
        }

        if ($closedTotal < $minClosed) {
            return [self::STATE_APPROVE_DEMO_SHADOW, self::ROUTE_DEMO, $insufficientReason];
        }
        if ($consecLosses >= $maxConsecLosses) {
            // Too many consecutive losses — keep to demo, do not block
            return [self::STATE_APPROVE_DEMO_SHADOW, self::ROUTE_DEMO, 'loss_streak'];
        }
        if ($winrate >= $minWinrate && $avgRoi >= $minAvgRoi) {
            return [self::STATE_APPROVE_LIVE_SHADOW, self::ROUTE_LIVE, 'live_gate_passed'];
        }
        if ($avgRoi < 0.0) {
            return [self::STATE_APPROVE_DEMO_SHADOW, self::ROUTE_DEMO, 'avg_roi_negative'];
        }
        if ($winrate < $minWinrate) {
            return [self::STATE_APPROVE_DEMO_SHADOW, self::ROUTE_DEMO, 'winrate_too_low'];
        }

        return [self::STATE_APPROVE_DEMO_SHADOW, self::ROUTE_DEMO, 'valid_demo_shadow'];
    }

    // =========================================================================
    // Decision record builder
    // =========================================================================

    /**
     * Build a decision journal record.
     *
     * @param array $norm  Normalised signal (or partial array for expired entries)
     */
    private function buildDecisionRecord(
        string  $govKey,
        array   $norm,
        ?string $prevState,
        string  $newState,
        string  $decision,
        string  $route,
        string  $reason,
        int     $tickCount,
        int     $maxTicks,
        string  $mode,
    ): array {
        return [
            'time'                     => date('Y-m-d H:i:s'),
            'decision_id'              => 'gd_' . substr(md5($govKey . microtime(true)), 0, 12),
            'governor_signal_key'      => $govKey,
            'signal_id'                => (string)($norm['signal_id']   ?? ''),
            'strategy_id'              => (string)($norm['strategy_id'] ?? ''),
            'symbol'                   => (string)($norm['symbol']      ?? ''),
            'previous_state'           => $prevState,
            'new_state'                => $newState,
            'decision'                 => $decision,
            'recommended_route'        => $route,
            'recommended_live_allowed' => ($route === self::ROUTE_LIVE),
            'reason'                   => $reason,
            'tick_count'               => $tickCount,
            'max_ticks'                => $maxTicks,
            'mode'                     => $mode,
        ];
    }

    // =========================================================================
    // Statistics builders
    // =========================================================================

    /**
     * Classify a single closed trade into primary / secondary / excluded
     * based on learning quality rules.
     *
     * @return array{quality: string, reason: string}
     */
    private function classifyTradeQuality(
        array $trade,
        array $primarySources,
        bool  $excludeEstimated,
        bool  $excludeDisappeared,
        bool  $excludePosGone,
        int   $maxAgeDays,
    ): array {
        $sid      = (string)($trade['strategy_id'] ?? $trade['owner_strategy'] ?? '');
        $roi      = $trade['roi'] ?? null;
        $closedAt = (string)($trade['closed_at'] ?? '');
        $source   = (string)($trade['close_source'] ?? '');
        $reason   = (string)($trade['close_reason'] ?? '');
        $isEst    = (bool)($trade['closed_at_is_estimated'] ?? false);

        // ── Excluded: missing required fields ─────────────────────────────────
        if ($sid === '') {
            return ['quality' => 'excluded', 'reason' => 'missing_strategy_id'];
        }
        if ($roi === null) {
            return ['quality' => 'excluded', 'reason' => 'missing_roi'];
        }
        if ($closedAt === '') {
            return ['quality' => 'excluded', 'reason' => 'missing_closed_at'];
        }
        $closedTs = $this->parseTimestamp($closedAt);
        if ($closedTs <= 0) {
            return ['quality' => 'excluded', 'reason' => 'missing_closed_at'];
        }

        // ── Condition flags ────────────────────────────────────────────────────
        $maxAgeSec    = $maxAgeDays * 86400;
        $tooOld       = (time() - $closedTs) > $maxAgeSec;
        $isDisappeared = ($source === 'exchange_disappeared' || $source === 'unknown');
        $isPosGone    = (
            $reason === 'position_gone_from_exchange'
            || $reason === 'position_gone_from_bybit_demo'
            || $reason === 'position_gone_from_bybit_live'
        );
        $isPrimarySource = in_array($source, $primarySources, true);

        // ── Primary check ─────────────────────────────────────────────────────
        if ($isPrimarySource
            && !($excludeEstimated && $isEst)
            && !($excludeDisappeared && $isDisappeared)
            && !($excludePosGone && $isPosGone)
            && !$tooOld
        ) {
            $qualReason = match ($source) {
                'profit_manager' => 'profit_manager_confirmed',
                'stop_manager'   => 'stop_manager_confirmed',
                default          => 'primary_source_confirmed',
            };
            return ['quality' => 'primary', 'reason' => $qualReason];
        }

        // ── Secondary: has roi + strategy_id but questionable attribution ──────
        if ($isDisappeared) {
            return ['quality' => 'secondary', 'reason' => 'exchange_disappeared_uncertain'];
        }
        if ($isPosGone) {
            return ['quality' => 'secondary', 'reason' => 'position_gone_from_exchange'];
        }
        if ($isEst) {
            return ['quality' => 'secondary', 'reason' => 'estimated_close_time'];
        }
        if ($tooOld) {
            return ['quality' => 'secondary', 'reason' => 'trade_too_old_for_primary'];
        }

        // Default secondary for any other source not in primary list
        return ['quality' => 'secondary', 'reason' => 'unknown_close_source'];
    }

    /**
     * Build per-strategy stats from a closed-trades array.
     *
     * When $lqEnabled is true, trades are classified into primary / secondary /
     * excluded buckets.  Top-level stats reflect primary data for backward
     * compatibility.  The full split is available in $stats[$sid]['primary'],
     * $stats[$sid]['secondary'], and $stats[$sid]['excluded'].
     *
     * @return array{stats: array<string, array>, counters: array}
     */
    private function buildStrategyStats(
        array $closedTrades,
        bool  $lqEnabled       = false,
        array $primarySources  = ['profit_manager', 'stop_manager'],
        array $secondarySources = ['exchange_disappeared', 'unknown'],
        bool  $excludeEstimated   = true,
        bool  $excludeDisappeared = true,
        bool  $excludePosGone     = true,
        int   $maxAgeDays         = 3,
    ): array {
        // Global quality counters
        $gSeenTotal            = 0;
        $gPrimaryTotal         = 0;
        $gSecondaryTotal       = 0;
        $gExcludedTotal        = 0;
        $gExchangeDisappeared  = 0;
        $gUnknownSource        = 0;
        $gEstimatedClose       = 0;
        $gTooOld               = 0;

        // Raw accumulator buckets per strategy
        // Each bucket: [total, wins, losses, roi_sum, pnl_sum, last_results[], last_at]
        $mkBucket = static fn() => [
            'total'        => 0,
            'wins'         => 0,
            'losses'       => 0,
            'roi_sum'      => 0.0,
            'pnl_sum'      => 0.0,
            'last_results' => [],
            'last_at'      => null,
            // secondary-only counters
            'exchange_disappeared' => 0,
            'unknown_close'        => 0,
            'estimated_close'      => 0,
            // excluded-only: reason counts
            'excluded_reasons' => [],
        ];

        $primary   = []; // keyed by $sid
        $secondary = []; // keyed by $sid
        $excluded  = []; // keyed by $sid

        foreach ($closedTrades as $trade) {
            $gSeenTotal++;
            $sid = (string)($trade['strategy_id'] ?? $trade['owner_strategy'] ?? '');
            $roi = isset($trade['roi']) ? (float)$trade['roi'] : null;
            $pnl = isset($trade['pnl']) ? (float)$trade['pnl'] : 0.0;
            $closedAt = (string)($trade['closed_at'] ?? '');
            $source   = (string)($trade['close_source'] ?? '');
            $reason   = (string)($trade['close_reason'] ?? '');

            if ($lqEnabled) {
                $cls = $this->classifyTradeQuality(
                    $trade, $primarySources, $excludeEstimated,
                    $excludeDisappeared, $excludePosGone, $maxAgeDays
                );
                $quality    = $cls['quality'];
                $clsReason  = $cls['reason'];
            } else {
                // When learning quality is disabled, treat all valid trades as primary
                $quality = ($sid !== '' && $roi !== null && $closedAt !== '') ? 'primary' : 'excluded';
                $clsReason = $quality === 'primary' ? 'learning_quality_disabled' : 'missing_required_field';
            }

            // Global counter tallying
            match ($quality) {
                'primary'   => $gPrimaryTotal++,
                'secondary' => $gSecondaryTotal++,
                'excluded'  => $gExcludedTotal++,
                default     => null,
            };
            if ($quality === 'secondary') {
                if ($source === 'exchange_disappeared') {
                    $gExchangeDisappeared++;
                }
                if ($source === 'unknown') {
                    $gUnknownSource++;
                }
                if ((bool)($trade['closed_at_is_estimated'] ?? false)) {
                    $gEstimatedClose++;
                }
                if ($clsReason === 'trade_too_old_for_primary') {
                    $gTooOld++;
                }
            }

            if ($sid === '') {
                continue; // no strategy → can't bin into per-strategy buckets
            }

            $bucket = match ($quality) {
                'primary'   => ($primary[$sid]   ?? null),
                'secondary' => ($secondary[$sid] ?? null),
                default     => ($excluded[$sid]  ?? null),
            };
            if ($bucket === null) {
                $bucket = $mkBucket();
            }

            if ($quality === 'excluded') {
                $bucket['excluded_reasons'][$clsReason] = ($bucket['excluded_reasons'][$clsReason] ?? 0) + 1;
                $bucket['total']++;
                $excluded[$sid] = $bucket;
                continue;
            }

            // primary or secondary
            $bucket['total']++;
            $bucket['pnl_sum'] += $pnl;
            $win = ($roi !== null && $roi > 0.0);
            if ($roi !== null) {
                $bucket['roi_sum'] += $roi;
            }
            if ($win) {
                $bucket['wins']++;
                $bucket['last_results'][] = 'win';
            } else {
                $bucket['losses']++;
                $bucket['last_results'][] = 'loss';
            }
            if ($closedAt !== '') {
                if ($bucket['last_at'] === null || $closedAt > $bucket['last_at']) {
                    $bucket['last_at'] = $closedAt;
                }
            }
            // Secondary-specific counters
            if ($quality === 'secondary') {
                if ($source === 'exchange_disappeared') {
                    $bucket['exchange_disappeared']++;
                }
                if ($source === 'unknown') {
                    $bucket['unknown_close']++;
                }
                if ((bool)($trade['closed_at_is_estimated'] ?? false)) {
                    $bucket['estimated_close']++;
                }
                $secondary[$sid] = $bucket;
            } else {
                $primary[$sid] = $bucket;
            }
        }

        // ── Compute derived fields helper ─────────────────────────────────────
        $deriveBucket = static function (array $b): array {
            $total = $b['total'];
            $w     = $b['wins'];
            $l     = $b['losses'];
            $results = $b['last_results'];
            $cl = $cw = 0;
            for ($i = count($results) - 1; $i >= 0; $i--) {
                if ($results[$i] === 'loss') {
                    if ($cw === 0) { $cl++; } else { break; }
                } else {
                    if ($cl === 0) { $cw++; } else { break; }
                }
            }
            $out = [
                'closed_trades_total' => $total,
                'wins_total'          => $w,
                'losses_total'        => $l,
                'winrate'             => $total > 0 ? round($w / $total, 4) : 0.0,
                'avg_roi'             => $total > 0 ? round($b['roi_sum'] / $total, 4) : 0.0,
                'total_pnl'           => round($b['pnl_sum'], 6),
                'consecutive_losses'  => $cl,
                'consecutive_wins'    => $cw,
                'last_trade_at'       => $b['last_at'],
            ];
            return $out;
        };

        // ── Build final per-strategy stats ────────────────────────────────────
        $stats = [];
        $stratsWithPrimary   = 0;
        $stratsOnlySecondary = 0;

        $allSids = array_unique(array_merge(
            array_keys($primary), array_keys($secondary), array_keys($excluded)
        ));
        foreach ($allSids as $sid) {
            $pBucket = $primary[$sid]   ?? null;
            $sBucket = $secondary[$sid] ?? null;
            $eBucket = $excluded[$sid]  ?? null;

            $primaryDerived   = $pBucket !== null ? $deriveBucket($pBucket) : null;
            $secondaryDerived = $sBucket !== null ? $deriveBucket($sBucket) : null;

            // Secondary sub-array with extra counters
            $secondaryOut = null;
            if ($sBucket !== null && $secondaryDerived !== null) {
                $secondaryOut = array_merge($secondaryDerived, [
                    'exchange_disappeared_total' => $sBucket['exchange_disappeared'],
                    'unknown_close_total'        => $sBucket['unknown_close'],
                    'estimated_close_total'      => $sBucket['estimated_close'],
                ]);
            }

            $excludedOut = $eBucket !== null
                ? ['total' => $eBucket['total'], 'reasons' => $eBucket['excluded_reasons']]
                : null;

            // Backward-compatible top-level: primary stats if available, else secondary, else zeros
            if ($primaryDerived !== null) {
                $topLevel = $primaryDerived;
                $stratsWithPrimary++;
            } elseif ($secondaryDerived !== null) {
                $topLevel = $secondaryDerived;
                $stratsOnlySecondary++;
            } else {
                $topLevel = [
                    'closed_trades_total' => 0,
                    'wins_total'          => 0,
                    'losses_total'        => 0,
                    'winrate'             => 0.0,
                    'avg_roi'             => 0.0,
                    'total_pnl'           => 0.0,
                    'consecutive_losses'  => 0,
                    'consecutive_wins'    => 0,
                    'last_trade_at'       => null,
                ];
            }

            $stats[$sid] = array_merge($topLevel, [
                'primary_closed_trades_total' => $primaryDerived !== null ? $primaryDerived['closed_trades_total'] : 0,
                'primary'   => $primaryDerived,
                'secondary' => $secondaryOut,
                'excluded'  => $excludedOut,
            ]);
        }

        $counters = [
            'closed_trades_seen_total'                 => $gSeenTotal,
            'closed_trades_primary_total'              => $gPrimaryTotal,
            'closed_trades_secondary_total'            => $gSecondaryTotal,
            'closed_trades_excluded_total'             => $gExcludedTotal,
            'closed_trades_exchange_disappeared_total' => $gExchangeDisappeared,
            'closed_trades_unknown_source_total'       => $gUnknownSource,
            'closed_trades_estimated_close_total'      => $gEstimatedClose,
            'closed_trades_too_old_for_primary_total'  => $gTooOld,
            'strategies_with_primary_stats_total'      => $stratsWithPrimary,
            'strategies_with_only_secondary_stats_total' => $stratsOnlySecondary,
        ];

        return ['stats' => $stats, 'counters' => $counters];
    }

    /**
     * Build hourly stats grouped by strategy_id + hour_of_day + weekday.
     *
     * When $lqEnabled is true, hourly_stats.json contains only primary trades.
     * Secondary hourly stats are written to hourly_secondary_stats.json.
     *
     * @return array  [$primaryHourly, $secondaryHourly]
     */
    private function buildHourlyStats(
        array $closedTrades,
        bool  $lqEnabled          = false,
        array $primarySources     = ['profit_manager', 'stop_manager'],
        bool  $excludeEstimated   = true,
        bool  $excludeDisappeared = true,
        bool  $excludePosGone     = true,
        int   $maxAgeDays         = 3,
    ): array {
        $primary   = [];
        $secondary = [];

        foreach ($closedTrades as $trade) {
            $sid      = (string)($trade['strategy_id'] ?? $trade['owner_strategy'] ?? '');
            $closedAt = (string)($trade['closed_at'] ?? '');
            if ($sid === '' || $closedAt === '') {
                continue;
            }
            $ts = $this->parseTimestamp($closedAt);
            if ($ts <= 0) {
                continue;
            }
            $hour    = (int)date('G', $ts);   // 0-23
            $weekday = (int)date('N', $ts);   // 1=Mon…7=Sun
            $key     = $hour . '_' . $weekday;
            $roi     = isset($trade['roi']) ? (float)$trade['roi'] : null;
            $pnl     = isset($trade['pnl']) ? (float)$trade['pnl'] : 0.0;

            if ($lqEnabled) {
                $cls     = $this->classifyTradeQuality(
                    $trade, $primarySources, $excludeEstimated,
                    $excludeDisappeared, $excludePosGone, $maxAgeDays
                );
                $quality = $cls['quality'];
            } else {
                $quality = 'primary'; // treat all as primary when quality is disabled
            }

            if ($quality === 'excluded') {
                continue;
            }

            if ($quality === 'primary') {
                if (!isset($primary[$sid][$key])) {
                    $primary[$sid][$key] = [
                        'hour_of_day'  => $hour,
                        'weekday'      => $weekday,
                        'trades_total' => 0,
                        'wins_total'   => 0,
                        'losses_total' => 0,
                        'roi_sum'      => 0.0,
                        'total_pnl'    => 0.0,
                    ];
                }
                $primary[$sid][$key]['trades_total']++;
                $primary[$sid][$key]['total_pnl'] += $pnl;
                if ($roi !== null) {
                    $primary[$sid][$key]['roi_sum'] += $roi;
                    if ($roi > 0.0) { $primary[$sid][$key]['wins_total']++; } else { $primary[$sid][$key]['losses_total']++; }
                } else {
                    $primary[$sid][$key]['losses_total']++;
                }
            } else {
                if (!isset($secondary[$sid][$key])) {
                    $secondary[$sid][$key] = [
                        'hour_of_day'  => $hour,
                        'weekday'      => $weekday,
                        'trades_total' => 0,
                        'wins_total'   => 0,
                        'losses_total' => 0,
                        'roi_sum'      => 0.0,
                        'total_pnl'    => 0.0,
                    ];
                }
                $secondary[$sid][$key]['trades_total']++;
                $secondary[$sid][$key]['total_pnl'] += $pnl;
                if ($roi !== null) {
                    $secondary[$sid][$key]['roi_sum'] += $roi;
                    if ($roi > 0.0) { $secondary[$sid][$key]['wins_total']++; } else { $secondary[$sid][$key]['losses_total']++; }
                } else {
                    $secondary[$sid][$key]['losses_total']++;
                }
            }
        }

        // Compute derived fields for both buckets
        $deriveHourly = static function (array $hourly): array {
            foreach ($hourly as &$buckets) {
                foreach ($buckets as &$h) {
                    $t = $h['trades_total'];
                    $h['winrate'] = $t > 0 ? round($h['wins_total'] / $t, 4) : 0.0;
                    $h['avg_roi'] = $t > 0 ? round($h['roi_sum']    / $t, 4) : 0.0;
                    unset($h['roi_sum']);
                }
                unset($h);
            }
            unset($buckets);
            return $hourly;
        };

        return [
            'primary'   => $deriveHourly($primary),
            'secondary' => $deriveHourly($secondary),
        ];
    }

    // =========================================================================
    // Strategy-state writer
    // =========================================================================

    private function saveStrategyStats(
        array $stratStats,
        array $openPerStrategy,
        array $strategyIds,
        int   $minClosed,
        float $minWinrate,
        float $minAvgRoi,
        int   $maxConsecLosses,
    ): void {
        $stateMap = [];
        foreach ($strategyIds as $sid) {
            $s = $stratStats[$sid] ?? [];

            // Use primary stats for the live gate check (primary_closed_trades_total
            // is set by buildStrategyStats when learning quality is enabled).
            $total      = (int)($s['primary_closed_trades_total'] ?? $s['closed_trades_total'] ?? 0);
            $winrate    = (float)($s['primary']['winrate']        ?? $s['winrate']  ?? 0.0);
            $avgRoi     = (float)($s['primary']['avg_roi']        ?? $s['avg_roi']  ?? 0.0);
            $consecLoss = (int)($s['primary']['consecutive_losses'] ?? $s['consecutive_losses'] ?? 0);

            $liveAllowed = false;
            $reason      = 'not_enough_primary_closed_trades';
            $state       = 'insufficient_data';

            if ($total >= $minClosed) {
                if ($consecLoss >= $maxConsecLosses) {
                    $reason = 'loss_streak';
                    $state  = 'shadow_observe';
                } elseif ($winrate >= $minWinrate && $avgRoi >= $minAvgRoi) {
                    $reason      = 'live_gate_passed';
                    $state       = 'shadow_live_ready';
                    $liveAllowed = true;
                } else {
                    $reason = 'below_live_threshold';
                    $state  = 'shadow_observe';
                }
            }

            $stateMap[$sid] = [
                'state'                    => $state,
                'recommended_live_allowed' => $liveAllowed,
                'recommended_route'        => $liveAllowed ? 'live' : 'demo',
                'reason'                   => $reason,
                // Backward-compatible totals (primary-based)
                'closed_trades_total'      => $total,
                'winrate'                  => $winrate,
                'avg_roi'                  => $avgRoi,
                'consecutive_losses'       => $consecLoss,
                'consecutive_wins'         => (int)($s['primary']['consecutive_wins'] ?? $s['consecutive_wins'] ?? 0),
                'total_pnl'                => round((float)($s['primary']['total_pnl'] ?? $s['total_pnl'] ?? 0.0), 6),
                'current_open_positions'   => $openPerStrategy[$sid] ?? 0,
                'last_trade_at'            => $s['primary']['last_trade_at'] ?? $s['last_trade_at'] ?? null,
                'updated_at'               => date('Y-m-d H:i:s'),
            ];
        }

        $this->writeJsonFile($this->moduleDir . '/storage/strategy_state.json', $stateMap);
        $this->writeJsonFile($this->moduleDir . '/storage/strategy_stats.json', $stratStats);
    }

    private function saveHourlyStats(array $hourlyResult): void
    {
        // $hourlyResult is the ['primary' => ..., 'secondary' => ...] array
        // returned by buildHourlyStats.
        $primaryHourly   = is_array($hourlyResult['primary']   ?? null) ? $hourlyResult['primary']   : $hourlyResult;
        $secondaryHourly = is_array($hourlyResult['secondary'] ?? null) ? $hourlyResult['secondary'] : [];

        // hourly_stats.json — primary only (backward-compatible key)
        $this->writeJsonFile($this->moduleDir . '/storage/hourly_stats.json', $primaryHourly);
        // hourly_secondary_stats.json — secondary only (new diagnostic file)
        if (!empty($secondaryHourly)) {
            $this->writeJsonFile($this->moduleDir . '/storage/hourly_secondary_stats.json', $secondaryHourly);
        }
    }

    // =========================================================================
    // Decision journal
    // =========================================================================

    /**
     * Append a batch of decision records to decisions.ndjson (one JSON object per line).
     */
    private function appendDecisions(array $decisions): void
    {
        if (empty($decisions)) {
            return;
        }
        $path  = $this->moduleDir . '/storage/decisions.ndjson';
        $lines = '';
        foreach ($decisions as $d) {
            $lines .= json_encode($d, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
        }
        @file_put_contents($path, $lines, FILE_APPEND | LOCK_EX);
    }

    // =========================================================================
    // Data loaders
    // =========================================================================

    /** Discover strategy IDs from the pattern directory. */
    private function discoverStrategies(): array
    {
        $patternDir = $this->repoRoot . '/modules/strategy/pattern';
        if (!is_dir($patternDir)) {
            return [];
        }
        $ids = [];
        foreach (scandir($patternDir) ?: [] as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            if (is_dir($patternDir . '/' . $entry)) {
                $ids[] = $entry;
            }
        }
        return $ids;
    }

    /**
     * Load all signals for a strategy.
     *
     * Reads signals.json and bot_handoff_queue.json, merges, deduplicates by signal_id.
     * Adds _source_file to each signal for traceability.
     */
    private function loadStrategySignals(string $stratId): array
    {
        $base = $this->repoRoot . '/modules/strategy/pattern/' . $stratId . '/storage';
        $sigs = [];
        $seen = [];

        foreach (['signals.json', 'bot_handoff_queue.json'] as $fname) {
            $relPath = 'modules/strategy/pattern/' . $stratId . '/storage/' . $fname;
            $arr     = $this->loadJsonSafe($base . '/' . $fname, []);
            if (!is_array($arr)) {
                continue;
            }
            foreach ($arr as $item) {
                if (!is_array($item)) {
                    continue;
                }
                $id = (string)($item['signal_id'] ?? $item['id'] ?? '');
                $k  = $id !== '' ? $id : json_encode($item);
                if (!isset($seen[$k])) {
                    $seen[$k]            = true;
                    $item['_source_file'] = $relPath;
                    $sigs[]              = $item;
                }
            }
        }
        return $sigs;
    }

    /** Load closed trades from bot storage (may not exist). */
    private function loadClosedTrades(): array
    {
        $path = $this->repoRoot . '/modules/bot/storage/trades/closed_trades.json';
        $data = $this->loadJsonSafe($path, []);
        return is_array($data) ? $data : [];
    }

    // =========================================================================
    // Persistence helpers
    // =========================================================================

    private function savePendingSignals(array $pending): void
    {
        $this->writeJsonFile($this->moduleDir . '/storage/pending_signals.json', $pending);
    }

    /**
     * Safely decode a JSON file; return $default on any failure.
     */
    private function loadJsonSafe(string $path, mixed $default): mixed
    {
        if (!is_file($path)) {
            return $default;
        }
        $raw = @file_get_contents($path);
        if ($raw === false || $raw === '') {
            return $default;
        }
        $decoded = @json_decode($raw, true);
        return ($decoded !== null) ? $decoded : $default;
    }

    /**
     * Write data as pretty-printed JSON, creating directories as needed.
     */
    private function writeJsonFile(string $path, mixed $data): void
    {
        $dir = dirname($path);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        @file_put_contents(
            $path,
            json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n",
            LOCK_EX
        );
    }

    /**
     * Parse a timestamp string or numeric value into a Unix timestamp.
     *
     * Accepts either an integer Unix timestamp (as int or numeric string) or
     * any date/time string understood by strtotime().  Returns 0 on failure.
     */
    private function parseTimestamp(string $value): int
    {
        if ($value === '') {
            return 0;
        }
        if (is_numeric($value)) {
            return (int)$value;
        }
        $ts = @strtotime($value);
        return ($ts !== false && $ts > 0) ? $ts : 0;
    }
}
